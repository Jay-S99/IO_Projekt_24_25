#include "pch.h"
#include <gtest/gtest.h>
#include "../biboloteka/BookManager.h"
#include "../biboloteka/UserManager.h"
#include "../biboloteka/LoanManager.h"
#include "../biboloteka/UserSystem.h"
#include "../biboloteka/Book.h"
#include "../biboloteka/User.h"
#include "../biboloteka/BookManager.cpp"
#include "../biboloteka/UserManager.cpp"
#include "../biboloteka/LoanManager.cpp"
#include "../biboloteka/UserSystem.cpp"
#include "../biboloteka/Book.cpp"
#include "../biboloteka/User.cpp"
#include<iostream>
using namespace std;

// Testy klasy UserManager
TEST(UserManagerTest, AddUser) {
    UserManager userManager;
    User user("Jan Kowalski");
    userManager.addUser(user);

    testing::internal::CaptureStdout();
    userManager.showAllUsers();
    string output = testing::internal::GetCapturedStdout();

    EXPECT_TRUE(output.find("Jan Kowalski") != string::npos);
}

TEST(UserManagerTest, FindUser) {
    UserManager userManager;
    User user("Anna Nowak");
    userManager.addUser(user);

    User* foundUser = userManager.findUser("Anna Nowak");
    EXPECT_NE(foundUser, nullptr);
    EXPECT_EQ(foundUser->getUsername(), "Anna Nowak");
}

// Testy klasy BookManager
TEST(BookManagerTest, AddBook) {
    BookManager bookManager;
    Book book("Pan Tadeusz", "Adam Mickiewicz");
    bookManager.addBook(book);

    testing::internal::CaptureStdout();
    bookManager.loadBooks();
    string output = testing::internal::GetCapturedStdout();

    EXPECT_TRUE(output.find("Pan Tadeusz") != string::npos);
}

TEST(BookManagerTest, SearchBook) {
    BookManager bookManager;
    Book book("Dziady", "Adam Mickiewicz");
    bookManager.addBook(book);

    Book* foundBook = bookManager.searchBook("Dziady");
    EXPECT_NE(foundBook, nullptr);
    EXPECT_EQ(foundBook->getTitle(), "Dziady");
}

// Testy klasy LoanManager
TEST(LoanManagerTest, LoanBook) {
    BookManager bookManager;
    LoanManager loanManager(bookManager);
    Book book("Lalka", "Boleslaw Prus");

    bookManager.addBook(book);
    loanManager.loanBook(book, "Jan Kowalski");

    testing::internal::CaptureStdout();
    loanManager.loanBook(book, "Jan Kowalski");
    string output = testing::internal::GetCapturedStdout();

    EXPECT_TRUE(output.find("Ksiazka wypozyczona!") != string::npos);
}

TEST(LoanManagerTest, ReturnBook) {
    BookManager bookManager;
    LoanManager loanManager(bookManager);
    Book book("Krzyzacy", "Henryk Sienkiewicz");

    bookManager.addBook(book);
    loanManager.loanBook(book, "Anna Nowak");
    loanManager.returnBook(book, "Anna Nowak");

    testing::internal::CaptureStdout();
    loanManager.returnBook(book, "Anna Nowak");
    string output = testing::internal::GetCapturedStdout();

    EXPECT_TRUE(output.find("Ksiazka zwrocona!") != string::npos);
}

// Testy klasy UserSystem
TEST(UserSystemTest, AddAndShowBook) {
    BookManager bookManager;
    UserManager userManager;
    LoanManager loanManager(bookManager);
    UserSystem system(bookManager, userManager, loanManager);

    testing::internal::CaptureStdout();
    system.addBook(); // Symulacja dodania ksi��ki przez u�ytkownika
    string output = testing::internal::GetCapturedStdout();

    EXPECT_TRUE(output.find("Podaj tytul ksiazki:") != string::npos);
}

// Funkcja main dla test�w
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
     cout<<RUN_ALL_TESTS();
     return RUN_ALL_TESTS();
    
}